#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <iomanip>

using namespace std;

// GroceryTracker class definition
class GroceryTracker {
private:
    map<string, int> itemFrequencies;

    // Helper function to load data from file into map
    void loadDataFromFile(const string& filename) {
        ifstream inFile(filename);
        string item;
        if (!inFile) {
            cerr << "Error: Could not open " << filename << endl;
            return;
        }
        while (inFile >> item) {
            itemFrequencies[item]++;
        }
        inFile.close();
    }

    // Helper function to write frequencies to frequency.dat
    void writeFrequencyData(const string& filename) {
        ofstream outFile(filename);
        if (!outFile) {
            cerr << "Error: Could not create " << filename << endl;
            return;
        }
        for (auto& pair : itemFrequencies) {
            outFile << pair.first << " " << pair.second << endl;
        }
        outFile.close();
    }

public:
    // Constructor - load initial data
    GroceryTracker(const string& inputFile, const string& outputFile) {
        loadDataFromFile(inputFile);
        writeFrequencyData(outputFile); // Backup file created automatically
    }

    // Menu Option 1: Get frequency of a specific item
    void getItemFrequency(const string& item) {
        if (itemFrequencies.count(item)) {
            cout << item << " was purchased " << itemFrequencies[item] << " times." << endl;
        }
        else {
            cout << item << " was not purchased today." << endl;
        }
    }

    // Menu Option 2: Display all items with their frequencies
    void displayAllFrequencies() {
        cout << "\nItem Purchase Frequencies:\n";
        for (auto& pair : itemFrequencies) {
            cout << left << setw(15) << pair.first << pair.second << endl;
        }
    }

    // Menu Option 3: Display histogram of items
    void displayHistogram() {
        cout << "\nPurchase Histogram:\n";
        for (auto& pair : itemFrequencies) {
            cout << left << setw(15) << pair.first;
            for (int i = 0; i < pair.second; i++) {
                cout << "*";
            }
            cout << endl;
        }
    }
};

int main() {
    GroceryTracker tracker("CS210_Project_Three_Input_File.txt", "frequency.dat");

    int choice;
    string itemName;

    do {
        cout << "\n===== Corner Grocer Menu =====\n";
        cout << "1. Search for item frequency\n";
        cout << "2. Display all item frequencies\n";
        cout << "3. Display histogram\n";
        cout << "4. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        // Validate user input
        if (cin.fail()) {
            cin.clear();
            cin.ignore(1000, '\n');
            cout << "Invalid input. Please enter a number from 1 to 4.\n";
            continue;
        }

        switch (choice) {
        case 1:
            cout << "Enter item name: ";
            cin >> itemName;
            tracker.getItemFrequency(itemName);
            break;
        case 2:
            tracker.displayAllFrequencies();
            break;
        case 3:
            tracker.displayHistogram();
            break;
        case 4:
            cout << "Exiting program. Goodbye!\n";
            break;
        default:
            cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 4);

    return 0;
}